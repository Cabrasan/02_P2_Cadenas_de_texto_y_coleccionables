import java.util.HashSet;
public class EX_10 {
    public static void main(String[] args){
        EX_10 app = new EX_10();
        app.hash_set();
    }
    public void hash_set(){

        HashSet<Integer> haaaash = new HashSet<>();

        haaaash.add(7);
        haaaash.add(17);
        haaaash.add(43);
        haaaash.add(4);
        haaaash.add(18);


        System.out.println(haaaash);

    }
}