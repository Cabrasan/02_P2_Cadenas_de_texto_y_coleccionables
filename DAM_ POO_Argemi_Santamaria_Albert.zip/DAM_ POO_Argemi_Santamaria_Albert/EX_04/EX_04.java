import java.util.Scanner;

public class EX_04 {
    Scanner v1 = new Scanner(System.in);
    Scanner v2 = new Scanner(System.in);
    public static void main(String[] args){
        EX_04 app = new EX_04();
        app.Contador_index();
    }

    public void Contador_index(){

        System.out.println("Escribe la palabra: ");
        String palabra = v1.nextLine();
        System.out.println("Introduzca el caracter: ");
        String caracter = v2.nextLine();

        System.out.println(palabra.indexOf(caracter));
    }

}
