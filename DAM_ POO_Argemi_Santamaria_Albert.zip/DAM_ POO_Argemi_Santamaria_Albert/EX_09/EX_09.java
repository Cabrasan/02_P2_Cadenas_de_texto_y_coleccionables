import java.util.*;
import java.util.stream.*;
public class EX_09 {
    public static <T> List<T> convertirArrayaLista(T array[])
    {

        List<T> list = new ArrayList<>();

        for (T t : array) {
            list.add(t);
        }

        return list;
    }

    public static void main(String args[])
    {
        String array[] = { "OPA OPA", "Uva bombon",
                "Uvaaaa" };

        System.out.println("Array: "
                + Arrays.toString(array));

        List<String>
                list = convertirArrayaLista(array);

        System.out.println("List: " + list);
    }
}
