import javax.swing.*;
import java.util.Scanner;

public class EX_01 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            String nombre;
            String apellido1;
            String apellido2;
            String iniciales;


            System.out.print("Nombre: ");
            nombre = scanner.nextLine();
            System.out.print("Primer apellido: ");
            apellido1 = scanner.nextLine();
            System.out.print("Segundo apellido: ");
            apellido2 = scanner.nextLine();

            iniciales = apellido1.substring(0,1)+apellido2.substring(0,1);

            System.out.println("Las iniciales son: " +nombre +iniciales);
        }
    }
