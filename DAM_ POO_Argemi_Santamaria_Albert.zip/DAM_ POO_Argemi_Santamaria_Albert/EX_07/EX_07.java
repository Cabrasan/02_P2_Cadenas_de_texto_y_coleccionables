import java.util.ArrayList;
import java.util.Iterator;

public class EX_07 {
    public static void main(String[] args){
        EX_07 app = new EX_07();
        app.iteracion();
    }
    public void iteracion(){

        ArrayList<String> Modelos_CAR = new ArrayList<String>();
        Modelos_CAR.add("Mercedes Class G");
        Modelos_CAR.add("BMW i8");
        Modelos_CAR.add("Lamborghini Aventador");
        Modelos_CAR.add("Mercedes GLC 550");
        Modelos_CAR.add("Ford Focus Competition");

        Iterator<String> it = Modelos_CAR.iterator();

        for (int i = 0; i < Modelos_CAR.size(); i++) {

            System.out.println(it.next());
        }
    }
}
