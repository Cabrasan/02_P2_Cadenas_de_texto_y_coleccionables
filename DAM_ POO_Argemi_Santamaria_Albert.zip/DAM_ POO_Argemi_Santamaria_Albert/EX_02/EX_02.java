import java.util.Scanner;

public class EX_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nombre;
        String apellido1;
        String iniciales;


        System.out.print("Nombre: ");
        nombre = scanner.nextLine();
        System.out.print("Primer apellido: ");
        apellido1 = scanner.nextLine();

        iniciales = nombre.substring(0,1);

        System.out.println("Las iniciales son: " +iniciales +apellido1);
    }
}
