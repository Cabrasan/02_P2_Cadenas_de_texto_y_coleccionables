import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;
public class EX_11 {
    public static void main(String[] args){
        EX_11 app = new EX_11();
        app.ordenar();
    }

    public void ordenar(){

        final Map<String, Integer> ordenar = new HashMap<>();
        ordenar.put("e", 3);
        ordenar.put("r", 4);
        ordenar.put("d", 9);
        ordenar.put("s", 1);
        ordenar.put("a", 2);
        ordenar.put("v", 4);
        ordenar.put("h", 3);
        ordenar.put("j", 8);
        ordenar.put("ñ", 6);

        final Map<String, Integer> sortedByCount = ordenar.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        System.out.println(sortedByCount);
    }
}
