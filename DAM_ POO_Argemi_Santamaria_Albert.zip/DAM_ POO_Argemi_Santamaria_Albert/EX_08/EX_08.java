import java.util.*;

public class EX_08 {
    public static void main(String[] args) {
        EX_08 app = new EX_08();
        app.function_lambda();
    }
    public void function_lambda() {


        ArrayList<Cantante> Cantantes = new ArrayList<Cantante>();
        Cantantes.add(new Cantante("Cano", 22));
        Cantantes.add(new Cantante("Kaydy Cain", 26));
        Cantantes.add(new Cantante("50CENT", 39));
        Cantantes.add(new Cantante("Yung Beef", 24));
        Cantantes.add(new Cantante("Khaled", 29));
        Cantantes.removeIf(Cantante -> (Cantante.edad <= 28)); // Expresion Lambda
        System.out.println("La lista de profes es: ");


        for (Cantante Cantante : Cantantes) {
            System.out.println(Cantante.nombre);
        }
    }

    private static class Cantante {
        private String nombre;
        private int edad;

        public Cantante(String nombre, int edad) {
            this.nombre = nombre;
            this.edad = edad;
        }
    }
    public class lista {
        public void main(String args[]) {

            List<Integer> lista1 = new ArrayList();

            lista1.add(1);
            lista1.add(2);

            int[] array = new int[lista1.size()];

            for(int i = 0; i < lista1.size(); i++)
                array[i] = lista1.get(i);
        }
    }
}
